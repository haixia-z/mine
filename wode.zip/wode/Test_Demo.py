#!/usr/bin/env python
# -*- coding:utf-8 -*-
import unittest
import time
from selenium import webdriver
from selenium.webdriver.common.by import By

class TestDemo(unittest.TestCase):
    # 初始化
    def setUp(self):
        print('开始执行')
        # 打开谷歌浏览器
        self.driver = webdriver.Chrome()
        # 窗口最大化
        self.driver.maximize_window()
        # 请求百度地址
        self.driver.get("http://39.106.127.16:8089/")
        # 隐性等待最长15秒
        self.driver.implicitly_wait(15)

    # 必须以test开头，否则unittest自动扫描不到，如果是suite.addTest(TestDemo('xxx'))执行测试用例则无所谓
    def test_J1102A(self):
        """选择设备 重整-J1102"""

        '''选择设备 重整-J1102A'''
        self.driver.find_element(By.XPATH,
                                 '//*[@id="leftAside"]/div[1]/div/div[2]/div[1]/div[2]/div/div[2]/div/div[2]/div/div[2]/div[2]/div/span[2]/span').click()
        '''选择 应急柴油机振动监测系统展开按钮'''
        self.driver.find_element(By.XPATH, '//*[@id="app"]/div/section/header/div[1]/ul/li[1]/div[1]').click()
        time.sleep(2)
        '''选择 机组概貌图'''
        self.driver.find_element(By.XPATH, '/html/body/div[2]/ul/li[1]').click()
        time.sleep(2)
        # 断言 机组概貌图是否显示
        error_mes = self.driver.find_element(By.XPATH, '//*[@id="infromtion"]/p[1]').text
        assert error_mes == 'J1102A'

        '''勾选 显示图谱'''
        self.driver.find_element(By.XPATH,
                                 '// *[ @ id = "app"] / div / section / section / div[2] / div / div[3] / div / section / label / span[1] / span').click()
        time.sleep(2)

        '''类型选择'''
        '''1,缸体振动监测'''
        self.driver.find_element(By.XPATH,
                                 '//*[@id="app"]/div/section/section/div[2]/div/div[3]/div/section/div/main/form/div[2]/div[1]/div/div/div/input').click()
        time.sleep(2)
        # self.driver.find_element(By.XPATH, '/html/body/div[5]/div[1]/div[1]/ul/li[1]/span').click()
        time.sleep(2)
        # 震动测点
        # a,峰值选择
        self.driver.find_element(By.XPATH,
                                 '//*[@id="app"]/div/section/section/div[2]/div/div[3]/div/section/div/main/form/div[2]/div[2]/div/div[1]/div[2]/div[1]/div[1]/div/div/div/span/span/i').click()  # 展开下拉项
        time.sleep(2)
        # self.driver.find_element(By.XPATH, '/html/body/div[11]/div[1]/div[1]/ul/li[1]/span').click()  #选择峰值
        time.sleep(2)

        for i in range(0, 2):  # 1缸壳体振动V
            self.driver.find_element(By.XPATH,
                                     '//*[@id="app"]/div/section/section/div[2]/div/div[3]/div/section/div/main/form/div[2]/div[2]/div/div[1]/div[2]/div[2]/div[1]/label/span/span').click()
            time.sleep(1)
            for j in range(0, 2):  # 2缸壳体振动V
                self.driver.find_element(By.XPATH,
                                         '//*[@id="app"]/div/section/section/div[2]/div/div[3]/div/section/div/main/form/div[2]/div[2]/div/div[1]/div[2]/div[3]/div[1]/label/span/span').click()
                time.sleep(1)
                for k in range(0, 2):  # 3缸壳体振动V
                    self.driver.find_element(By.XPATH,
                                             '//*[@id="app"]/div/section/section/div[2]/div/div[3]/div/section/div/main/form/div[2]/div[2]/div/div[1]/div[2]/div[4]/div[1]/label/span/span').click()
                    time.sleep(1)
                    for z in range(0, 2):  # 3缸壳体振动V
                        self.driver.find_element(By.XPATH,
                                                 '//*[@id="app"]/div/section/section/div[2]/div/div[3]/div/section/div/main/form/div[2]/div[2]/div/div[1]/div[2]/div[5]/div[1]/label/span/span').click()
                        time.sleep(1)

    def test_isUpper(self):
        """判断单词是否大写"""
        self.assertTrue("SELENIUo".isupper(), msg='错误：单词不是大写')

    # 销毁
    def tearDown(self):
        self.driver.quit()
        print('执行结束')


"""
if __name__ == '__main__':
    unittest.main()
"""
