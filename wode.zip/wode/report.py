#!/usr/bin/env python 
# -*- coding:utf-8 -*-
import time
import unittest
import yagmail
import HTMLTestRunner
from Test_Demo import TestDemo


if __name__ == '__main__':
    suite = unittest.TestSuite()
    # 执行测试用例
    # 方案一：手动一个一个添加
    # suite.addTest(TestDemo('test_searchTitle'))
    # suite.addTest(TestDemo('test_readCsv'))

    # 方案二：自动识别并执行所有测试用例 路径（./: 当前文件） + 要匹配的文件名
    discover = unittest.defaultTestLoader.discover('./', pattern='Test_*.py')

    # 获取当前时间作为文件名
    now = time.strftime('%Y%m%d-%H%M%S')
    filename = 'E://课件/bishe/wode/report/测试报告_' + now + '_test.html'

    fp = open(filename, 'wb')

    # 生成html文件
    runner = HTMLTestRunner.HTMLTestRunner(
        stream=fp,
        verbosity=2,
        title="应急柴油机振动监测系统测试报告",
        description="测试报告的详情")

    # runner.run(suite)
    runner.run(discover)

    fp.close()

    # 发送邮件 中文标题记得加上encoding='GBK'，小心乱码哦
    # 发送方+授权码+邮箱服务器地址+编码处理
    yag = yagmail.SMTP(user='2785927599@qq.com', password='1781202@ZHXzhx', host='smtp.qq.com', encoding='GBK')
    # 内容+附件
    content = ['您好，以下是应急柴油机振动监测系统测试报告告，请查收。', filename]
    # 发送
    yag.send('2528443402@qq.com', u'自动化测试报告', content)

    yag.close()
