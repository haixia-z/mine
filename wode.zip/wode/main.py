import unittest
import warnings
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
'''批量执行测试用例'''

class testunit1(unittest.TestCase):
	@classmethod
	def setUpClass(self) -> None:
		print('所有用例的前置-1')
	@classmethod
	def tearDownClass(self) -> None:
		print('所有用例的后置--最后')

	def setUp(self) -> None:
		'''每个用例的前置，打开浏览器'''


	def tearDown(self) -> None:
		print('每个用例的后置')

	def testcase01(self):
		a=1/0
		print('模块1测试用例1')

	def testcase02(self):
		print('模块1测试用例2')

class testunit2(unittest.TestCase):
	def testcase001(self):
		print('模块2测试用例1')

	def testcase002(self):
		print('模块2测试用例2')

unittest.main(verbosity=2)  #运行所有类的所有用例

'''if __name__ == '__main__':

 #一个类、多个类、多个py文件的部分用例执行
	run_cases=unittest.TestSuite()  #创建一个测试套件
	run_cases.addTests([testunit1('testcase01'),
	                    testunit2('testcase001'),
	                    ])
	runner = unittest.TextTestRunner() #执行器
	runner.run(run_cases)'''

#一个类、多个类（多次添加）、多个py文件的所有用例执行
'''run_cases=unittest.TestSuite()  #创建一个测试套件
    run_cases.addTests(unittest.TestLoader().loadTestsFromTestCase(testunit1))
    runner = unittest.TextTestRunner()
    runner.run(run_cases)'''

