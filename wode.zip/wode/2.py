import unittest
import warnings
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

'''unittest+selenium 框架'''
class testunit1(unittest.TestCase):
	driver = None

	@classmethod
	def setUpClass(self) -> None:
		'''每个用例的前置，打开浏览器'''
		self.driver = webdriver.Chrome()
		self.driver.get("http://39.106.127.16:8089/")
		time.sleep(5)

		'''选择设备 重整-J1102A'''
		self.driver.find_element(By.XPATH, '//*[@id="leftAside"]/div[1]/div/div[2]/div[1]/div[2]/div/div[2]/div/div[2]/div/div[2]/div[2]/div/span[2]/span').click()
		'''选择 应急柴油机振动监测系统展开按钮'''
		self.driver.find_element(By.XPATH, '//*[@id="app"]/div/section/header/div[1]/ul/li[1]/div[1]').click()
		time.sleep(2)
		'''选择 机组概貌图'''
		self.driver.find_element(By.XPATH, '/html/body/div[2]/ul/li[1]').click()
		time.sleep(2)
		error_mes = self.driver.find_element(By.XPATH, '//*[@id="infromtion"]/p[1]').text
		print(error_mes)
		#assert error_mes == u'请您填写手机/邮箱/用户名'




	@classmethod
	def tearDownClass(self) -> None:
		'''每个用例的后置，关闭浏览器'''

	def testcase001(self):
		print('模块2测试用例1')

	'''	time.sleep(2)
		self.driver.quit()
		'''

unittest.main(verbosity=2)  # 运行所有类的所有用例




