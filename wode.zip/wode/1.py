import time
from selenium import webdriver
from selenium.webdriver.common.by import By

'''控制浏览器驱动，定位元素方法的使用'''

driver = webdriver.Chrome()
driver.get("https://www.baidu.com")
# 获取url和title并打印
print(driver.current_url)
print(driver.title)

shuru = driver.find_element(By.ID, 'kw')
shuru.send_keys("selenium")
driver.find_element(By.ID, 'su').click()
# 获取文本框内容并打印
print(shuru.get_attribute("value"))
# 清除文本框内容
time.sleep(2)
shuru.clear()

# 获取页面底部信息
xinxi = driver.find_element(By.ID, 's-bottom-layer-content')
print(xinxi.get_attribute("textContent"))

time.sleep(5)
'''driver.quit()'''
