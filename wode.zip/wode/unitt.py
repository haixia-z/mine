import unittest
import warnings
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
#启动chrome浏览器
driver = webdriver.Chrome()
#进入qq邮箱登陆首页
driver.get("https://mail.qq.com/")
time.sleep(1)

#窗口最大化
driver.maximize_window()
#########登陆
#输入用户名

#将xxxxxxxxxx换成qq邮箱账户
driver.find_element(By.XPATH,"//*[@id='u']").send_keys('2785927599@qq.com')
#输入密码：将1111111111替换为自己的邮箱密码
driver.find_element(By.ID,'p').send_keys('1781202@ZHXzhx')
#点击登陆
driver.find_element(By.ID,'login_button').click()
time.sleep(10)
#断言登陆成功
assert '退出' in driver.page_source

#########写信

#切换到mainFrame
driver.switch_to.frame('mainFrame')
time.sleep(2)
#输入收件人
driver.find_element(By.XPATH,"//*[@id='toAreaCtrl']/div[2]/input").send_keys('2528443402@qq.com')
#输入主题
driver.find_element(By.ID,'subject').send_keys('TEST')
#输入正文


#点击发送按钮
driver.find_element(By.XPATH,"//*[@id='toolbar']/div/a[1]").click()
time.sleep(3)
##driver.find_element_by_xpath('//a[@name="sendbtn" and @tabindex="9"]').click()
time.sleep(3)
#断言发送成功
assert u"再写一封" in driver.page_source
#关闭浏览器
driver.quit()